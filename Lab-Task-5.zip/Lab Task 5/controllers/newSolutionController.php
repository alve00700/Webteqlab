<?php
require_once '../models/model.php';

function askSolutionTypes() {
    return getSolutionTypes();
}

function validateSolution($data) {
    $time = time();
    $solutionID = $data['username'] . $time;
    $data['solutionID'] = $solutionID;

    $data['challenge'] = saveContentToFile($data['challenge'], $solutionID, 'challenge', $time);
    $data['solutionBody'] = saveContentToFile($data['solutionBody'], $solutionID, 'solution', $time);
    $data['result'] = saveContentToFile($data['result'], $solutionID, 'result', $time);

    $addSolution = addSolution($data);

    foreach ($data['selectedSpecializations'] as $specialization) {
        $d['type'] = "solution";
        $d['id'] = $solutionID;
        $d['sector'] = $specialization;
        addSpecialization($d);
    }

    if ($data['fileName'] != "") {
        UploadFile($data['fileName'], $data['fileTmpName'], $solutionID);
    }

    return $addSolution;
}

function saveContentToFile($content, $solutionID, $type, $time) {
    $filename = "../uploads/{$solutionID}-{$type}-{$time}.txt";
    $file = fopen($filename, "w") or die("Unable to open file!");
    fwrite($file, $content);
    fclose($file);
    return $filename;
}

function UploadFile($fileName, $fileTmpName, $solutionId) {
    // Upload logic here
}

function askAllSectors() {
    $rows = getAllSectors();
    $specializations = array();
    foreach ($rows as $row) {
        $specializations[] = $row['name'];
    }
    return $specializations;
}
?>
