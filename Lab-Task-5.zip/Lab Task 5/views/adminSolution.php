<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Solution</title>
    <style>
        body {
            font-family: sans-serif;
            margin: 0;
            padding: 0;
        }
        h1 {
            font-size: 24px;
            margin-bottom: 10px;
        }
        h3 {
            font-size: 18px;
            margin-bottom: 10px;
        }
        img {
            max-width: 100%;
            height: auto;
        }
        form {
            margin: 20px 0;
        }
        input[type="submit"] {
            width: 100px;
            height: 30px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
        }
    </style>
</head>
<body>
<?php require 'nav.php'; ?>
<br>
<h1><?php echo $solution['title'] ?></h1>
<?php 
    foreach($specializations as $specialization){
        echo "| ".$specialization." | ";
    }
?><br>
<?php echo "| ".$solution['region']." | " ?><br>
<?php echo $solution['publicationDate'] ?><br>
<?php echo $solutionProviderName ?><br>
<hr>
<?php 
    if($solution['media']!=null){
        echo "<img src='".$solution['media']."' alt='' height='480' width='720'>";
    }
?>
<h3>Challenge</h3>
<?php echo $challenge ?>
<br><br>
<h3>Solution</h3>
<?php echo $solutionBody ?>
<br><br>
<h3>Result</h3>
<?php echo $result ?>
<hr>
<br><?php echo "Status: " . $solution['status'] ?><br>
<hr>
<form action="../controllers/adminSolutionAction.php" method="post">
    <input type="hidden" name="id" value="<?php echo $solution['solutionID'] ?>">
    <label for="comment">Short Comment:</label><br>
    <textarea name="comment" id="comment" cols="30" rows="10"></textarea><br>
    <input type="submit" name="submit" value="Approve" style="background-color: green">
    <input type="submit" name="submit" value="Revision" style="background-color: orange">
    <input type="submit" name="submit" value="Reject" style="background-color: red">
</form>
    
</body>
</html>
