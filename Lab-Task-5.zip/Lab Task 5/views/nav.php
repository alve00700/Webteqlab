<!DOCTYPE html>
<html>
<head>
    <title>Styling Links</title>
</head>
<body>

<a href="solutionProviderView.php" style="color: blue; text-decoration: none;">Solution Provider</a><br>
<a href="adminView.php" style="color: green; text-decoration: none;">Admin</a><br>
<a href="publicView.php" style="color: red; text-decoration: none;">Solutions</a><br>

</body>
</html>
