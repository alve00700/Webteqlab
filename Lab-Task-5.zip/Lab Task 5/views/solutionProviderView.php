<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solution Provider</title>
    <style>
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
        }
        h1 {
            color: #333;
        }
        a {
            color: #0066cc;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <?php require 'nav.php';?>
    <br>
    <h1>Solution Provider</h1><br>
    <a href="newSolution.php">Submit New Solution</a><br>
    <a href="reviseSolution.php">Revise Solution</a>
</body>
</html>
