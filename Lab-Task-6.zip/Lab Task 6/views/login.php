<?php
require '../controllers/loginController.php';
$username = $password = $remember = $msg="";

if(isset($_COOKIE["username"])){
    $username=$_COOKIE["username"];
    $password=$_COOKIE["password"];
}

if($_SERVER["REQUEST_METHOD"]=="POST"){
    if(isset($_POST["submit"])){
        $username=$_POST["username"];
        $password=$_POST["password"];
        if(isset($_POST["remember"])){
            $remember=$_POST["remember"];
        } else {
            $remember="";
        }
        $msg = validateLogin($username,$password, $remember);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
}

form {
    display: flex;
    flex-direction: column;
    align-items: start;
}

label {
    margin: 10px 0;
    font-size: 16px;
    color: #333;
}

input[type="text"], input[type="password"], input[type="submit"] {
    margin: 10px 0;
    padding: 10px;
    font-size: 16px;
    width: 100%;
    max-width: 400px;
    border: 2px solid #ccc;
    border-radius: 4px;
    transition: border-color 0.3s ease;
}

input[type="text"]:focus, input[type="password"]:focus {
    border-color: #0066cc;
}

input[type="submit"] {
    background-color: #0066cc;
    color: #fff;
    border: none;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

input[type="submit"]:hover {
    background-color: #004d99;
}

.error {
    color: red;
    margin: 5px 0;
}

.success {
    color: green;
    margin: 5px 0;
}
</style>

</head>
<body>
    <?php require 'nav.php';?>
    <br>
    <h1>Login</h1>
    <form action="login.php" method="post">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" value="<?php echo $username ?>" >
        <br>
        <label for="password">Password:</label>
        <input type="password" name="password" id="password" value="<?php echo $password ?>">
        <br>
        <input type="checkbox" name="remember" id="remember" value="Remember" <?php if(isset($_COOKIE["username"])){echo "checked";} ?>>
        <label for="remember">Remember Me</label><br><hr>
        <input type="submit" name ="submit" value="Login">
    </form>
    <br>
    <?php echo $msg; ?>
</body>
</html>