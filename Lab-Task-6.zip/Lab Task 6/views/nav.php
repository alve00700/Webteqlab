<a href="publicHome.php">Public Home</a> || 
<a href="registration.php">Registration</a> || 
<a href="login.php">Login</a>