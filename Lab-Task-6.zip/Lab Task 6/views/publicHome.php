<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Public Home</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    transition: background-color 0.3s ease;
}

body:hover {
    background-color: #e0e0e0;
}

h1 {
    color: #333;
    text-align: center;
    transition: color 0.3s ease;
}

h1:hover {
    color: #0066cc;
    transform: scale(1.1);
}

nav {
    background-color: #333;
    color: #fff;
    padding: 10px 0;
    transition: background-color 0.3s ease;
}

nav:hover {
    background-color: #444;
}

nav a {
    color: #fff;
    text-decoration: none;
    margin: 0 10px;
    transition: color 0.3s ease;
}

nav a:hover {
    color: #0066cc;
}
</style>
</head>
<body>
    <?php require 'nav.php';?>
    <br>
    <h1>Public Home</h1>
</body>
</html>