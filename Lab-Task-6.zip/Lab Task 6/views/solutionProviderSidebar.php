<ul>
    <li><a href="solutionProviderDashboard.php">Dashboard</a></li>
    <li><a href="solutionProviderViewProfile.php">Veiw Profile</a></li>
    <li><a href="solutionProviderEditProfile.php">Edit Profile</a></li>
    <li><a href="changePassword.php">Change Password</a></li>
    <li><a href="logout.php">Logout</a></li>
</ul>