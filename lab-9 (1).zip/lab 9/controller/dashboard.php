<?php
session_start();

?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    
</head>
<body>
    <?php
    if (isset($_SESSION['user_id'])) { // Check if user is logged in
        echo '<div class="dashboard" id="dashboard">
                  <h1>Dashboard</h1>
                  <table class="dashboard-table">
                      <tr>
                          <th>Tabs</th>
                      </tr>
                      <tr>
                          <td><a class="dashboard-links" href="../UpdateUserInformation.php">Edit Profile</a></td>
                      </tr>
                      <tr>
                          <td><a class="dashboard-links" href="../showUserinfo.php">View Profile</a></td>
                      </tr>
                      <tr>
                          <td><a class="dashboard-links" href="changePassword.php">Change Password</a></td>
                      </tr>
                      <tr>
                          <td><a class="dashboard-links" href="../HomePage.php?activate_session=true">Home Page</a></td>

                      </tr>
                         <tr>
                          <td><a class="dashboard-links" href="logout.php">Log Out</a></td>
                      </tr>
                      

                  </table>
              </div>';
    } else {
        echo "Please log in to access the dashboard.";
    }
    ?>

    <div class="toggle-dashboard" id="toggleDashboard">View Dashboard Content</div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#toggleDashboard").click(function() {
                $("#dashboard").toggleClass("active");
            });
        });
    </script>
</body>
</html>


