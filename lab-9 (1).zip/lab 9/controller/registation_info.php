<?php 

require_once ('model/model.php');

function fetchAllusers(){
	return showAllusers();

}
function fetchUser($id){
	return showUser($id);

}

?>