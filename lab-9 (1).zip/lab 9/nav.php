 <ul>
        <li><a href="Addproduct.php"> Add Product</a></li>
        <li><a href="show_all_product.php"> Show all Products</a></li>
        <li><a href="search_product.php"> Search a Product</a></li> 

    </ul>