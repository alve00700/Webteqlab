<!DOCTYPE html>
<html>
<head>
    <title>Search for Products</title>
</head>
<body>
    
    <!-- [SEARCH FORM] -->
    <form method="post" action="controller/findProduct.php">
      <h1>SEARCH FOR PRODUCTS</h1>
      <input type="text" name="product_name" />
      <input type="submit" name="findProduct" value="Search"/>
    </form>
</body>
</html>
