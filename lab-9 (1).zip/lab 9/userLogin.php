<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
 
</head>
<body>
    <h1>Login</h1>
    <ul>
        <li class="nav-item active"><a href="MainHome.php">Home</a></li>
        <li class="nav-item"><a href="Registationpage.html">Signup</a></li>
    </ul>
    <div class="container">
        <form name="login" action="controller/login.php" method="POST" enctype="multipart/form-data" onsubmit="return validateForm()">
            <label for="email">Email:</label>
            <input type="text" name="email" class="form-control" placeholder="Enter your Email">
            <label for="passWord">Password:</label>
            <input type="password" name="passWord" class="form-control" placeholder="Enter your Password">
            <input type="submit" name="submit" value="Submit" class="btn">
            <div class="create-account">
                <a href="Registationpage.html">Create an account</a>
            </div>
        </form>
    </div>
</body>
</html>
